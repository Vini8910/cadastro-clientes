
# Cadastro de Clientes (Projeto Estudo)

Sistema de cadastro de clientes com:
- Formulário HTML
- Máscaras e validação com jQuery
- Envio de dados via AJAX
- Backend em PHP com estrutura de classe
- Banco de dados em SQLite (simulando uso do Firebird na Multidados)

## Funcionalidades
- Cadastro de nome, CPF/CNPJ e tipo de pessoa
- Validação de campos
- Exibição de mensagens de sucesso/erro

## Estrutura
```
cadastro-clientes/
├── index.html
├── js/script.js
├── css/style.css
├── api/api.php
├── api/ClienteData.php
├── db/banco.sqlite
```

## Como usar
1. Coloque os arquivos em um servidor local (ex: XAMPP, WAMP, Laragon)
2. Acesse `index.html`
3. Preencha os dados e envie
